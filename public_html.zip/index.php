<?php
require __DIR__ . '/../app/core.php';

$router = new \App\Router();
$router->dispatch();
